#Practica #1
numero1 = input("Ingresa el primer número: ")
numero2 = input("Ingresa el segundo número: ")

numero1 = int(numero1)
numero2 = int(numero2)

resultado = numero1 + numero2

print("La suma de los dos números es:", resultado)